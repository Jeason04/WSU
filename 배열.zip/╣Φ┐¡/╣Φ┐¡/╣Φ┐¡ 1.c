#include<stdio.h>
void exam1();
void exam3();
void exam4();
void exam5();
void exam6();
void exam7();
void exam2();


void main() {
	exam1();
}

void exam1() {
	int arr[10] = {0};
	for (int i = 0; i < 10; i++)
		printf("%2d", arr[i]);
	printf("\n");
	int arr1[10];
	for (int i = 0; i < 10; i++){
		arr1[i] = i+1;
		printf("%3d", arr1[i]);
	}
	printf("\n");
	char arr2[26];
	for (int i = 0; i < 26; i++) {
		arr2[i] = 'a' + i;
		printf("%2c", arr2[i]);
	}

}