//#include <stdio.h>
//
//void main() {
//
//	char ch;
//	scanf_s("%c", &ch);
//
//	if ('a' <= ch && ch <= 'z')
//		printf("small letter");
//	else if ('A' <= ch && ch <= 'Z')
//	{
//		printf("capital letter");
//	}
//	else
//		printf("symble");
//
//}