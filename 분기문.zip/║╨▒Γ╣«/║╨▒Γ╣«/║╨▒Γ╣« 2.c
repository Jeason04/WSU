//#include <stdio.h>
//
//void main() {
//
//	char str;
//	scanf_s("%c", &str);
//	if (str - '0')
//		printf("%d", (int)str);
//	else
//		printf("%c", str);
//}