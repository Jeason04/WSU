//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//
//void main(){
//	int num;
//	printf("�����Է� : ");
//	scanf("%d", &num);
//
//	if (num > 10 && num < 20)
//		printf("%d", num * 2);
//
//	else
//		printf("%d", num);
//}