//#include<stdio.h>
//
//void main() {
//	char ch;
//	scanf_s("%c", &ch);
//	if ('a' <= ch && ch <= 'z') {
//		ch = ch - ('a' - 'A');
//		printf("%c", ch);
//	}
//	else if ('A' <= ch && ch <= 'Z'){
//		ch = ch - ('A' - 'a');
//		printf("%c", ch);
//	}
//}