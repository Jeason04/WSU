//#include<stdio.h>
//void main() {
//
//	int num;
//	scanf_s("%d", &num);
//	if (num % 2 == 0)
//		printf("even number");
//	else
//		printf("odd number");
//}